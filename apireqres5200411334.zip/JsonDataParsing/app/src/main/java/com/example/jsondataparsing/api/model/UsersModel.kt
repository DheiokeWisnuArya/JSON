package com.example.jsondataparsing.api.model

data class UsersModel(
    val data:ArrayList<Users>
)
