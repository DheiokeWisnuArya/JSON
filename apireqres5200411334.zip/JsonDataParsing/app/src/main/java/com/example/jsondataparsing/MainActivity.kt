package com.example.jsondataparsing

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.jsondataparsing.api.ApiClient
import com.example.jsondataparsing.api.adapter.UsersAdapter
import com.example.jsondataparsing.api.model.Users
import com.example.jsondataparsing.api.model.UsersModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    val listData = ArrayList<Users>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        showDataUsers()

    }

    private fun showDataUsers(){


        val rvUsers: RecyclerView = findViewById(R.id.rv_users)
        rvUsers.setHasFixedSize(true)
        rvUsers.layoutManager = LinearLayoutManager(this)

        val connection = ApiClient.create()

        val callData: Call<UsersModel> = connection.getUsers()

        callData.enqueue(object :Callback<UsersModel>{
            override fun onResponse(call: Call<UsersModel>, response: Response<UsersModel>) {
                val itemData = response.body()?.data

                itemData?.let { listData.addAll(it) }

                val adapterData = UsersAdapter(listData)

                rvUsers.adapter = adapterData

            }
//                 Log.d("DATA", itemData.toString())


            override fun onFailure(call: Call<UsersModel>, t: Throwable) {
                Log.e("ERROR", t.message.toString())
            }

        })

    }
}