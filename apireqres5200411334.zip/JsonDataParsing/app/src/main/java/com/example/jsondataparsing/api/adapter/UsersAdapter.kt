package com.example.jsondataparsing.api.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.jsondataparsing.R
import com.example.jsondataparsing.api.model.Users

class UsersAdapter (private val datalist: ArrayList<Users>):
    RecyclerView.Adapter<UsersAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsersAdapter.ViewHolder {

        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_users, parent, false)

        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UsersAdapter.ViewHolder, position: Int) {

        val item = datalist[position]

        holder.id.text = item.id.toString()
        holder.email.text = item.email
        holder.firstName.text = item.firstName
        holder.lastName.text = item.lastName

    }

    override fun getItemCount(): Int = datalist.size

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){

        val id: TextView = itemView.findViewById(R.id.tv_id)
        val email: TextView = itemView.findViewById(R.id.tv_email)
        val firstName: TextView = itemView.findViewById(R.id.tv_first_name)
        val lastName: TextView = itemView.findViewById(R.id.tv_last_name)
    }
}